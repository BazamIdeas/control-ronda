let node_env = process.env.NODE_ENV || "development";

let config = {
  production: {
    API_BASE: "http://api.cs100.cl/v1",
    API_URL: "http://apicc.bazamdev.com/v3/",
    GOOGLE_API: "AIzaSyCGpy9AMuzWleErmqXLC2yZciwl5gostYI"
  },
  development: {
    API_BASE: "http://127.0.0.1:9090/v1",
    API_URL: "http://127.0.0.1:3000/v3/",
    GOOGLE_API: "AIzaSyCGpy9AMuzWleErmqXLC2yZciwl5gostYI"
  }
};

module.exports = config[node_env];
